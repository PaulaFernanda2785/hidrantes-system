<?php

use App\Core\Session;

$baseStylesheets = [
    'globals/variables.css',
    'globals/reset.css',
    'globals/base.css',
    'components/cards.css',
    'components/alerts.css',
    'components/forms.css',
    'components/buttons.css',
    'pages/auth.css',
];
$stylesheets = array_values(array_unique(array_merge(
    $baseStylesheets,
    $pageStylesheets ?? []
)));
$headLinks = array_values(array_unique($headLinks ?? []));
$externalScripts = array_values(array_unique($externalScripts ?? []));
$pageScripts = array_values(array_unique(array_merge([
    'core/app.js',
], $scripts ?? [])));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'Login') ?></title>
    <link rel="icon" href="/img/ico/logo.cbmpa.ico" type="image/x-icon">
    <?php foreach ($stylesheets as $stylesheet): ?>
        <link rel="stylesheet" href="<?= e(css_asset($stylesheet)) ?>">
    <?php endforeach; ?>
    <?php foreach ($headLinks as $headLink): ?>
        <link rel="stylesheet" href="<?= e($headLink) ?>">
    <?php endforeach; ?>
</head>
<body class="auth-page">
    <main class="auth-wrapper">
        <?php if ($error = Session::getFlash('error')): ?>
            <div class="alert alert-error"><?= e($error) ?></div>
        <?php endif; ?>
        <?php if ($success = Session::getFlash('success')): ?>
            <div class="alert alert-success"><?= e($success) ?></div>
        <?php endif; ?>
        <?= $content ?>
    </main>
    <?php foreach ($externalScripts as $externalScript): ?>
        <script src="<?= e($externalScript) ?>" defer></script>
    <?php endforeach; ?>
    <?php foreach ($pageScripts as $script): ?>
        <script src="<?= e(js_asset($script)) ?>" defer></script>
    <?php endforeach; ?>
</body>
</html>
